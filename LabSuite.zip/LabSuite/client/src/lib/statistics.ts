/**
 * Statistical analysis utility functions
 * Basic implementations for common statistical tests
 */

export interface DescriptiveStats {
  n: number;
  mean: number;
  median: number;
  sd: number;
  sem: number;
  min: number;
  max: number;
  q1: number;
  q3: number;
}

export interface TTestResult {
  t: number;
  df: number;
  pValue: number;
  significant: boolean;
  meanDiff: number;
  ci95: [number, number];
  descriptive: {
    group1: DescriptiveStats;
    group2: DescriptiveStats;
  };
}

export interface ANOVAResult {
  f: number;
  dfBetween: number;
  dfWithin: number;
  pValue: number;
  significant: boolean;
  descriptive: { [key: string]: DescriptiveStats };
  posthoc?: PosthocResult[];
}

export interface PosthocResult {
  comparison: string;
  meanDiff: number;
  pValueAdj: number;
  significant: boolean;
  ci95: [number, number];
}

/**
 * Calculate descriptive statistics for a dataset
 */
export function calculateDescriptiveStats(values: number[]): DescriptiveStats {
  if (values.length === 0) {
    throw new Error('Cannot calculate statistics for empty dataset');
  }

  const sorted = [...values].sort((a, b) => a - b);
  const n = values.length;
  const sum = values.reduce((acc, val) => acc + val, 0);
  const mean = sum / n;
  
  // Calculate variance and standard deviation
  const variance = values.reduce((acc, val) => acc + Math.pow(val - mean, 2), 0) / (n - 1);
  const sd = Math.sqrt(variance);
  const sem = sd / Math.sqrt(n);
  
  // Calculate quartiles
  const q1Index = Math.floor(n * 0.25);
  const q3Index = Math.floor(n * 0.75);
  const medianIndex = Math.floor(n * 0.5);
  
  return {
    n,
    mean: parseFloat(mean.toFixed(3)),
    median: n % 2 === 0 ? 
      (sorted[medianIndex - 1] + sorted[medianIndex]) / 2 : 
      sorted[medianIndex],
    sd: parseFloat(sd.toFixed(3)),
    sem: parseFloat(sem.toFixed(3)),
    min: sorted[0],
    max: sorted[n - 1],
    q1: sorted[q1Index],
    q3: sorted[q3Index],
  };
}

/**
 * Perform independent samples t-test
 */
export function performTTest(group1: number[], group2: number[]): TTestResult {
  if (group1.length < 2 || group2.length < 2) {
    throw new Error('Each group must have at least 2 observations for t-test');
  }

  const stats1 = calculateDescriptiveStats(group1);
  const stats2 = calculateDescriptiveStats(group2);
  
  // Welch's t-test (unequal variances)
  const variance1 = Math.pow(stats1.sd, 2);
  const variance2 = Math.pow(stats2.sd, 2);
  
  const pooledSE = Math.sqrt(variance1 / stats1.n + variance2 / stats2.n);
  const t = (stats1.mean - stats2.mean) / pooledSE;
  
  // Welch's degrees of freedom
  const df = Math.pow(variance1 / stats1.n + variance2 / stats2.n, 2) / 
    (Math.pow(variance1 / stats1.n, 2) / (stats1.n - 1) + 
     Math.pow(variance2 / stats2.n, 2) / (stats2.n - 1));
  
  // Approximate p-value using t-distribution approximation
  const pValue = approximateTTestPValue(Math.abs(t), df);
  
  const meanDiff = stats1.mean - stats2.mean;
  const marginOfError = 1.96 * pooledSE; // Approximate 95% CI
  const ci95: [number, number] = [meanDiff - marginOfError, meanDiff + marginOfError];
  
  return {
    t: parseFloat(t.toFixed(3)),
    df: Math.round(df),
    pValue: parseFloat(pValue.toFixed(4)),
    significant: pValue < 0.05,
    meanDiff: parseFloat(meanDiff.toFixed(3)),
    ci95: [parseFloat(ci95[0].toFixed(3)), parseFloat(ci95[1].toFixed(3))],
    descriptive: {
      group1: stats1,
      group2: stats2,
    },
  };
}

/**
 * Perform one-way ANOVA
 */
export function performANOVA(groups: { [key: string]: number[] }): ANOVAResult {
  const groupNames = Object.keys(groups);
  
  if (groupNames.length < 2) {
    throw new Error('ANOVA requires at least 2 groups');
  }
  
  // Check minimum sample sizes
  for (const name of groupNames) {
    if (groups[name].length < 2) {
      throw new Error(`Group '${name}' must have at least 2 observations`);
    }
  }
  
  const descriptive: { [key: string]: DescriptiveStats } = {};
  let totalSum = 0;
  let totalN = 0;
  const allValues: number[] = [];
  
  // Calculate descriptive stats for each group
  groupNames.forEach(name => {
    const stats = calculateDescriptiveStats(groups[name]);
    descriptive[name] = stats;
    totalSum += stats.mean * stats.n;
    totalN += stats.n;
    allValues.push(...groups[name]);
  });
  
  const grandMean = totalSum / totalN;
  
  // Calculate sum of squares
  let ssBetween = 0;
  let ssWithin = 0;
  
  groupNames.forEach(name => {
    const groupData = groups[name];
    const groupMean = descriptive[name].mean;
    const groupN = groupData.length;
    
    // Between group sum of squares
    ssBetween += groupN * Math.pow(groupMean - grandMean, 2);
    
    // Within group sum of squares
    groupData.forEach(value => {
      ssWithin += Math.pow(value - groupMean, 2);
    });
  });
  
  const dfBetween = groupNames.length - 1;
  const dfWithin = totalN - groupNames.length;
  const msBetween = ssBetween / dfBetween;
  const msWithin = ssWithin / dfWithin;
  const f = msBetween / msWithin;
  
  // Approximate p-value using F-distribution approximation
  const pValue = approximateFTestPValue(f, dfBetween, dfWithin);
  
  return {
    f: parseFloat(f.toFixed(3)),
    dfBetween,
    dfWithin,
    pValue: parseFloat(pValue.toFixed(4)),
    significant: pValue < 0.05,
    descriptive,
  };
}

/**
 * Approximate p-value for t-test using normal approximation for large df
 */
function approximateTTestPValue(t: number, df: number): number {
  // For large df (>30), t-distribution approximates normal distribution
  if (df > 30) {
    return 2 * (1 - approximateNormalCDF(t));
  }
  
  // Simple approximation for smaller df
  // This is a rough approximation and should be replaced with proper t-distribution CDF
  const adjustedT = t * Math.sqrt(df / (df + 1));
  return 2 * (1 - approximateNormalCDF(adjustedT));
}

/**
 * Approximate p-value for F-test
 */
function approximateFTestPValue(f: number, df1: number, df2: number): number {
  // Very rough approximation - in production, use proper F-distribution CDF
  if (f < 1) return 1;
  if (f > 10) return 0.001;
  if (f > 5) return 0.01;
  if (f > 3) return 0.05;
  if (f > 2) return 0.1;
  return 0.2;
}

/**
 * Approximate standard normal CDF using error function approximation
 */
function approximateNormalCDF(x: number): number {
  // Abramowitz and Stegun approximation
  const a1 = 0.254829592;
  const a2 = -0.284496736;
  const a3 = 1.421413741;
  const a4 = -1.453152027;
  const a5 = 1.061405429;
  const p = 0.3275911;
  
  const sign = x < 0 ? -1 : 1;
  x = Math.abs(x) / Math.sqrt(2.0);
  
  const t = 1.0 / (1.0 + p * x);
  const y = 1.0 - (((((a5 * t + a4) * t) + a3) * t + a2) * t + a1) * t * Math.exp(-x * x);
  
  return 0.5 * (1.0 + sign * y);
}

/**
 * Parse CSV data into groups for statistical analysis
 */
export function parseDataForAnalysis(
  csvData: string,
  groupColumn: string,
  valueColumn: string
): { [key: string]: number[] } {
  const lines = csvData.trim().split('\n');
  if (lines.length < 2) {
    throw new Error('CSV must contain header and at least one data row');
  }
  
  const headers = lines[0].split(',').map(h => h.trim().replace(/"/g, ''));
  const groupIndex = headers.indexOf(groupColumn);
  const valueIndex = headers.indexOf(valueColumn);
  
  if (groupIndex === -1) {
    throw new Error(`Group column '${groupColumn}' not found in CSV`);
  }
  if (valueIndex === -1) {
    throw new Error(`Value column '${valueColumn}' not found in CSV`);
  }
  
  const groups: { [key: string]: number[] } = {};
  
  for (let i = 1; i < lines.length; i++) {
    const row = lines[i].split(',').map(cell => cell.trim().replace(/"/g, ''));
    
    if (row.length <= Math.max(groupIndex, valueIndex)) continue;
    
    const group = row[groupIndex];
    const valueStr = row[valueIndex];
    
    if (!group || !valueStr) continue;
    
    const value = parseFloat(valueStr);
    if (isNaN(value)) continue;
    
    if (!groups[group]) {
      groups[group] = [];
    }
    groups[group].push(value);
  }
  
  return groups;
}
