import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { Calculator, FlaskConical, Beaker } from "lucide-react";

export default function DilutionCalculator() {
  const { toast } = useToast();

  // Simple ratio calculator state
  const [totalVolume1, setTotalVolume1] = useState("1000");
  const [dilutionRatio, setDilutionRatio] = useState("1:500");
  const [results1, setResults1] = useState<{ stockVolume: string; diluentVolume: string } | null>(null);

  // C1V1 = C2V2 calculator state
  const [c1, setC1] = useState("");
  const [c2, setC2] = useState("");
  const [v2, setV2] = useState("10");
  const [units, setUnits] = useState("mg/mL");
  const [results2, setResults2] = useState<{ v1: string; diluent: string } | null>(null);

  const parseRatio = (ratioString: string): [number, number] | null => {
    const match = ratioString.replace(/\s+/g, '').match(/(\d+(?:\.\d+)?):(\d+(?:\.\d+)?)/);
    if (!match) return null;
    return [parseFloat(match[1]), parseFloat(match[2])];
  };

  const calculateSimpleRatio = () => {
    const ratio = parseRatio(dilutionRatio);
    if (!ratio) {
      toast({
        title: "Invalid Ratio",
        description: "Please enter a valid ratio (e.g., 1:500)",
        variant: "destructive",
      });
      return;
    }

    const totalVol = parseFloat(totalVolume1);
    if (!totalVol || totalVol <= 0) {
      toast({
        title: "Invalid Volume",
        description: "Please enter a valid total volume",
        variant: "destructive",
      });
      return;
    }

    const [numerator, denominator] = ratio;
    const totalParts = numerator + denominator;
    const stockVolume = totalVol * (numerator / totalParts);
    const diluentVolume = totalVol - stockVolume;

    setResults1({
      stockVolume: stockVolume.toFixed(2),
      diluentVolume: diluentVolume.toFixed(2),
    });

    toast({
      title: "Calculation Complete",
      description: "Simple ratio dilution calculated successfully.",
    });
  };

  const calculateC1V1 = () => {
    const C1 = parseFloat(c1);
    const C2 = parseFloat(c2);
    const V2 = parseFloat(v2);

    if (!C1 || !C2 || !V2 || C1 <= 0 || C2 <= 0 || V2 <= 0) {
      toast({
        title: "Invalid Values",
        description: "Please enter positive numbers for all concentrations and volumes",
        variant: "destructive",
      });
      return;
    }

    if (C2 >= C1) {
      toast({
        title: "Invalid Concentrations",
        description: "Final concentration (C2) must be less than stock concentration (C1)",
        variant: "destructive",
      });
      return;
    }

    // C1V1 = C2V2, solve for V1
    const V1 = (C2 * V2) / C1; // mL
    const diluentVolume = V2 - V1; // mL

    setResults2({
      v1: (V1 * 1000).toFixed(2), // Convert to µL
      diluent: (diluentVolume * 1000).toFixed(2), // Convert to µL
    });

    toast({
      title: "Calculation Complete",
      description: "C1V1 = C2V2 dilution calculated successfully.",
    });
  };

  return (
    <div className="space-y-8">
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-neutral-700 mb-2">Laboratory Calculators</h2>
        <p className="text-neutral-500">Essential calculation tools for laboratory work including dilution preparations and solution calculations.</p>
      </div>

      {/* Simple Ratio Calculator */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <FlaskConical className="w-5 h-5 text-blue-600" />
            <span>Simple Ratio Dilution (e.g., 1:500)</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="totalVolume1">Total Volume (µL)</Label>
              <Input
                id="totalVolume1"
                type="number"
                step="1"
                value={totalVolume1}
                onChange={(e) => setTotalVolume1(e.target.value)}
                placeholder="e.g., 1000"
              />
            </div>
            <div>
              <Label htmlFor="dilutionRatio">Dilution Ratio</Label>
              <Input
                id="dilutionRatio"
                value={dilutionRatio}
                onChange={(e) => setDilutionRatio(e.target.value)}
                placeholder="1:500"
              />
            </div>
          </div>

          <Button onClick={calculateSimpleRatio} className="bg-blue-600 hover:bg-blue-700">
            <Calculator className="w-4 h-4 mr-2" />
            Calculate
          </Button>

          {results1 && (
            <Card className="bg-neutral-50">
              <CardContent className="p-4">
                <div className="grid grid-cols-2 gap-4 text-center">
                  <div>
                    <p className="text-sm text-neutral-500 mb-1">Stock Volume</p>
                    <p className="text-lg font-semibold text-neutral-700">{results1.stockVolume} µL</p>
                  </div>
                  <div>
                    <p className="text-sm text-neutral-500 mb-1">Diluent Volume</p>
                    <p className="text-lg font-semibold text-neutral-700">{results1.diluentVolume} µL</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </CardContent>
      </Card>

      {/* C1V1 = C2V2 Calculator */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Beaker className="w-5 h-5 text-green-600" />
            <span>C1V1 = C2V2 Calculator</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="c1">C1 (Stock Concentration)</Label>
              <Input
                id="c1"
                type="number"
                step="0.0001"
                value={c1}
                onChange={(e) => setC1(e.target.value)}
                placeholder="e.g., 2"
              />
            </div>
            <div>
              <Label htmlFor="c2">C2 (Final Concentration)</Label>
              <Input
                id="c2"
                type="number"
                step="0.0001"
                value={c2}
                onChange={(e) => setC2(e.target.value)}
                placeholder="e.g., 0.002"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="v2">V2 (Total Volume, mL)</Label>
              <Input
                id="v2"
                type="number"
                step="0.001"
                value={v2}
                onChange={(e) => setV2(e.target.value)}
                placeholder="e.g., 10"
              />
            </div>
            <div>
              <Label htmlFor="units">Units</Label>
              <Select value={units} onValueChange={setUnits}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="mg/mL">mg/mL</SelectItem>
                  <SelectItem value="µg/mL">µg/mL</SelectItem>
                  <SelectItem value="ng/mL">ng/mL</SelectItem>
                  <SelectItem value="mM">mM</SelectItem>
                  <SelectItem value="µM">µM</SelectItem>
                  <SelectItem value="nM">nM</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <Button onClick={calculateC1V1} className="bg-green-600 hover:bg-green-700">
            <Calculator className="w-4 h-4 mr-2" />
            Calculate
          </Button>

          {results2 && (
            <Card className="bg-neutral-50">
              <CardContent className="p-4">
                <div className="grid grid-cols-2 gap-4 text-center">
                  <div>
                    <p className="text-sm text-neutral-500 mb-1">V1 (Stock to add)</p>
                    <p className="text-lg font-semibold text-neutral-700">{results2.v1} µL</p>
                  </div>
                  <div>
                    <p className="text-sm text-neutral-500 mb-1">Diluent Volume</p>
                    <p className="text-lg font-semibold text-neutral-700">{results2.diluent} µL</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </CardContent>
      </Card>

      {/* Additional Calculations Info */}
      <Card>
        <CardHeader>
          <CardTitle>Calculation Notes</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h4 className="font-medium text-neutral-700 mb-2">Simple Ratio Dilutions</h4>
              <ul className="text-sm text-neutral-600 space-y-1">
                <li>• Used when you know the desired ratio (e.g., 1:500)</li>
                <li>• Stock volume = Total × (numerator / total parts)</li>
                <li>• Commonly used for antibody dilutions</li>
                <li>• Example: 1:1000 in 1mL = 1µL stock + 999µL diluent</li>
              </ul>
            </div>
            <div>
              <h4 className="font-medium text-neutral-700 mb-2">C1V1 = C2V2</h4>
              <ul className="text-sm text-neutral-600 space-y-1">
                <li>• Used when you know exact concentrations</li>
                <li>• V1 = (C2 × V2) / C1</li>
                <li>• Commonly used for drug/reagent preparations</li>
                <li>• Ensure C1 {">"} C2 (diluting, not concentrating)</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
