import { useLocation } from "wouter";
import { Link } from "wouter";
import { 
  Home, 
  BarChart3, 
  BookOpen, 
  PawPrint, 
  Calendar, 
  TestTubeDiagonal, 
  Snowflake, 
  Calculator
} from "lucide-react";

const navigationItems = [
  { path: "/", label: "Dashboard", icon: Home },
  { path: "/statistics", label: "Statistics", icon: BarChart3 },
  { path: "/lab-notebook", label: "Lab Notebook", icon: BookOpen },
  { path: "/animal-log", label: "Animal Log", icon: PawPrint },
  { path: "/experiment-scheduler", label: "Scheduler", icon: Calendar },
  { path: "/antibody-registry", label: "Registry", icon: TestTubeDiagonal },
  { path: "/freezer-inventory", label: "Inventory", icon: Snowflake },
  { path: "/dilution-calculator", label: "Tools", icon: Calculator },
];

export default function Navigation() {
  const [location] = useLocation();

  return (
    <nav className="bg-white border-b border-neutral-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex space-x-8 overflow-x-auto">
          {navigationItems.map(({ path, label, icon: Icon }) => {
            const isActive = location === path;
            return (
              <Link
                key={path}
                href={path}
                className={`px-3 py-4 text-sm font-medium whitespace-nowrap border-b-2 transition-colors flex items-center space-x-2 ${
                  isActive
                    ? "text-blue-600 border-blue-600"
                    : "text-neutral-500 hover:text-neutral-700 border-transparent hover:border-neutral-300"
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{label}</span>
              </Link>
            );
          })}
        </div>
      </div>
    </nav>
  );
}
