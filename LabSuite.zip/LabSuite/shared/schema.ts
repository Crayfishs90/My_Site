import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, real, date, timestamp, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const labNotebookEntries = pgTable("lab_notebook_entries", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  date: date("date").notNull(),
  title: text("title").notNull(),
  experimentId: text("experiment_id"),
  project: text("project"),
  tags: text("tags"),
  content: text("content").notNull(),
  links: text("links"),
  author: text("author").notNull(),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const animalLogs = pgTable("animal_logs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  date: date("date").notNull(),
  mouseId: text("mouse_id").notNull(),
  strain: text("strain").notNull(),
  sex: text("sex").notNull(),
  dateOfBirth: date("date_of_birth"),
  ageWeeks: real("age_weeks"),
  treatment: text("treatment"),
  weight: real("weight"),
  observations: text("observations"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const experimentSchedules = pgTable("experiment_schedules", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  date: date("date").notNull(),
  title: text("title").notNull(),
  pi: text("pi"),
  operator: text("operator"),
  species: text("species"),
  nPlanned: integer("n_planned"),
  groups: text("groups"),
  due: date("due"),
  status: text("status").notNull().default("planned"),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const antibodyRegistry = pgTable("antibody_registry", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  date: date("date").notNull(),
  target: text("target").notNull(),
  clone: text("clone"),
  host: text("host"),
  reactivity: text("reactivity"),
  vendor: text("vendor"),
  catalog: text("catalog"),
  lot: text("lot"),
  dilution: text("dilution"),
  application: text("application"),
  storage: text("storage"),
  box: text("box"),
  position: text("position"),
  expiry: date("expiry"),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const slideRegistry = pgTable("slide_registry", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  slideId: text("slide_id").notNull(),
  date: date("date").notNull(),
  region: text("region"),
  thickness: integer("thickness"),
  stains: text("stains"),
  box: text("box"),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const freezerInventory = pgTable("freezer_inventory", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  box: text("box").notNull(),
  position: text("position"),
  sampleId: text("sample_id").notNull(),
  type: text("type"),
  dateIn: date("date_in").notNull(),
  dateOut: date("date_out"),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({ id: true });
export const insertLabNotebookEntrySchema = createInsertSchema(labNotebookEntries).omit({ id: true, createdAt: true });
export const insertAnimalLogSchema = createInsertSchema(animalLogs).omit({ id: true, createdAt: true });
export const insertExperimentScheduleSchema = createInsertSchema(experimentSchedules).omit({ id: true, createdAt: true });
export const insertAntibodyRegistrySchema = createInsertSchema(antibodyRegistry).omit({ id: true, createdAt: true });
export const insertSlideRegistrySchema = createInsertSchema(slideRegistry).omit({ id: true, createdAt: true });
export const insertFreezerInventorySchema = createInsertSchema(freezerInventory).omit({ id: true, createdAt: true });

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertLabNotebookEntry = z.infer<typeof insertLabNotebookEntrySchema>;
export type LabNotebookEntry = typeof labNotebookEntries.$inferSelect;
export type InsertAnimalLog = z.infer<typeof insertAnimalLogSchema>;
export type AnimalLog = typeof animalLogs.$inferSelect;
export type InsertExperimentSchedule = z.infer<typeof insertExperimentScheduleSchema>;
export type ExperimentSchedule = typeof experimentSchedules.$inferSelect;
export type InsertAntibodyRegistry = z.infer<typeof insertAntibodyRegistrySchema>;
export type AntibodyRegistry = typeof antibodyRegistry.$inferSelect;
export type InsertSlideRegistry = z.infer<typeof insertSlideRegistrySchema>;
export type SlideRegistry = typeof slideRegistry.$inferSelect;
export type InsertFreezerInventory = z.infer<typeof insertFreezerInventorySchema>;
export type FreezerInventory = typeof freezerInventory.$inferSelect;

// Statistical analysis types
export const statisticalAnalysisSchema = z.object({
  csvData: z.string(),
  groupColumn: z.string(),
  valueColumn: z.string(),
  testType: z.enum(["ttest", "anova", "kruskal"]),
});

export type StatisticalAnalysisRequest = z.infer<typeof statisticalAnalysisSchema>;
