import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { downloadCSV } from "@/lib/csv-utils";
import { Search, Plus, Download, Edit, Trash2, Microscope } from "lucide-react";
import type { SlideRegistry, InsertSlideRegistry } from "@shared/schema";

export default function SlideRegistry() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Form state
  const [formData, setFormData] = useState<InsertSlideRegistry>({
    slideId: "",
    date: new Date().toISOString().split('T')[0],
    region: "",
    thickness: 30,
    stains: "",
    box: "",
    notes: "",
  });

  // Search state
  const [searchQuery, setSearchQuery] = useState("");

  // Fetch slide registry
  const { data: slides = [], isLoading } = useQuery<SlideRegistry[]>({
    queryKey: ['/api/slide-registry'],
  });

  // Create slide entry mutation
  const createMutation = useMutation({
    mutationFn: (data: InsertSlideRegistry) => 
      apiRequest("POST", "/api/slide-registry", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/slide-registry'] });
      setFormData({
        slideId: "",
        date: new Date().toISOString().split('T')[0],
        region: "",
        thickness: 30,
        stains: "",
        box: "",
        notes: "",
      });
      toast({
        title: "Slide Registered",
        description: "Slide has been added to the registry successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Save Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Export mutation
  const exportMutation = useMutation({
    mutationFn: () => fetch('/api/export/slide-registry').then(r => r.text()),
    onSuccess: (csvData) => {
      downloadCSV(csvData, 'slide_registry.csv');
      toast({
        title: "Export Complete",
        description: "Slide registry data exported successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Export Failed",
        description: "Failed to export slide registry data.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    createMutation.mutate(formData);
  };

  const handleInputChange = (field: keyof InsertSlideRegistry, value: string | number) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const clearForm = () => {
    setFormData({
      slideId: "",
      date: new Date().toISOString().split('T')[0],
      region: "",
      thickness: 30,
      stains: "",
      box: "",
      notes: "",
    });
  };

  // Filter slides based on search
  const filteredSlides = slides.filter(slide => {
    const searchTerm = searchQuery.toLowerCase();
    return (
      slide.slideId.toLowerCase().includes(searchTerm) ||
      slide.region?.toLowerCase().includes(searchTerm) ||
      slide.stains?.toLowerCase().includes(searchTerm) ||
      slide.box?.toLowerCase().includes(searchTerm)
    );
  });

  if (isLoading) {
    return (
      <div className="space-y-8">
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-neutral-700 mb-2">Slide Registry</h2>
          <p className="text-neutral-500">Maintain detailed records of histology slides including tissue regions and staining protocols.</p>
        </div>
        <div className="animate-pulse space-y-4">
          <Card className="p-6">
            <div className="h-4 bg-gray-200 rounded w-1/4 mb-4"></div>
            <div className="grid grid-cols-3 gap-4">
              {[1, 2, 3].map(i => <div key={i} className="h-10 bg-gray-200 rounded"></div>)}
            </div>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-neutral-700 mb-2">Slide Registry</h2>
        <p className="text-neutral-500">Maintain detailed records of histology slides including tissue regions and staining protocols.</p>
      </div>

      {/* New Slide Form */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg font-semibold text-neutral-700">Register New Slide</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <Label htmlFor="slideId">Slide ID</Label>
                <Input
                  id="slideId"
                  placeholder="e.g., M12-SNpc-04"
                  value={formData.slideId}
                  onChange={(e) => handleInputChange('slideId', e.target.value)}
                  required
                />
              </div>
              <div>
                <Label htmlFor="date">Date</Label>
                <Input
                  id="date"
                  type="date"
                  value={formData.date}
                  onChange={(e) => handleInputChange('date', e.target.value)}
                  required
                />
              </div>
              <div>
                <Label htmlFor="region">Tissue / Region</Label>
                <Input
                  id="region"
                  placeholder="e.g., SNpc, Ileum"
                  value={formData.region}
                  onChange={(e) => handleInputChange('region', e.target.value)}
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <Label htmlFor="thickness">Thickness (µm)</Label>
                <Input
                  id="thickness"
                  type="number"
                  step="1"
                  value={formData.thickness?.toString() || ''}
                  onChange={(e) => handleInputChange('thickness', e.target.value ? parseInt(e.target.value) : 0)}
                />
              </div>
              <div>
                <Label htmlFor="stains">Stain(s)</Label>
                <Input
                  id="stains"
                  placeholder="e.g., TH, DAPI"
                  value={formData.stains}
                  onChange={(e) => handleInputChange('stains', e.target.value)}
                />
              </div>
              <div>
                <Label htmlFor="box">Storage (Box/Pos)</Label>
                <Input
                  id="box"
                  placeholder="e.g., Box12 A3"
                  value={formData.box}
                  onChange={(e) => handleInputChange('box', e.target.value)}
                />
              </div>
            </div>

            <div>
              <Label htmlFor="notes">Notes</Label>
              <Textarea
                id="notes"
                rows={3}
                placeholder="Additional notes about the slide, protocols used, observations..."
                value={formData.notes}
                onChange={(e) => handleInputChange('notes', e.target.value)}
              />
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <Button
                  type="submit"
                  disabled={createMutation.isPending}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  {createMutation.isPending ? (
                    <>
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
                      Registering...
                    </>
                  ) : (
                    <>
                      <Plus className="w-4 h-4 mr-2" />
                      Register Slide
                    </>
                  )}
                </Button>
                <Button
                  type="button"
                  onClick={() => exportMutation.mutate()}
                  disabled={exportMutation.isPending}
                  className="bg-green-600 hover:bg-green-700"
                >
                  {exportMutation.isPending ? (
                    <>
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
                      Exporting...
                    </>
                  ) : (
                    <>
                      <Download className="w-4 h-4 mr-2" />
                      Export CSV
                    </>
                  )}
                </Button>
              </div>
              <Button
                type="button"
                variant="ghost"
                onClick={clearForm}
                className="text-neutral-500 hover:text-neutral-700"
              >
                Clear Form
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>

      {/* Search */}
      <Card>
        <CardContent className="p-6">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-neutral-400 w-4 h-4" />
            <Input
              placeholder="Search slides by ID, region, stains, or storage box..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
        </CardContent>
      </Card>

      {/* Slide Registry Table */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg font-semibold text-neutral-700">Slide Registry</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          {filteredSlides.length === 0 ? (
            <div className="text-center py-12">
              <Microscope className="mx-auto h-16 w-16 text-neutral-400 mb-4" />
              <p className="text-neutral-500">No slides registered</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-neutral-200">
                <thead className="bg-neutral-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Slide ID</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Date</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Region</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Thickness (µm)</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Stains</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Storage</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Notes</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Actions</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-neutral-200">
                  {filteredSlides.map((slide) => (
                    <tr key={slide.id} className="hover:bg-neutral-50">
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-neutral-700">
                        {slide.slideId}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-600">
                        {new Date(slide.date).toLocaleDateString()}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-600">
                        {slide.region}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-600">
                        {slide.thickness}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-600">
                        {slide.stains}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-600">
                        {slide.box}
                      </td>
                      <td className="px-6 py-4 text-sm text-neutral-600 max-w-xs truncate">
                        {slide.notes}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-500">
                        <div className="flex items-center space-x-2">
                          <Button variant="ghost" size="sm" className="text-blue-600 hover:text-blue-800">
                            <Edit className="w-4 h-4" />
                          </Button>
                          <Button variant="ghost" size="sm" className="text-red-600 hover:text-red-800">
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
