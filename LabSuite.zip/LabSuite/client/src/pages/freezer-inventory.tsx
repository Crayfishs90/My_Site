import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { downloadCSV } from "@/lib/csv-utils";
import { Search, Plus, Download, Edit, Trash2, Snowflake, Package } from "lucide-react";
import type { FreezerInventory, InsertFreezerInventory } from "@shared/schema";

export default function FreezerInventory() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Form state
  const [formData, setFormData] = useState<InsertFreezerInventory>({
    box: "",
    position: "",
    sampleId: "",
    type: "",
    dateIn: new Date().toISOString().split('T')[0],
    dateOut: "",
    notes: "",
  });

  // Search state
  const [searchQuery, setSearchQuery] = useState("");

  // Fetch freezer inventory
  const { data: inventory = [], isLoading } = useQuery<FreezerInventory[]>({
    queryKey: ['/api/freezer-inventory'],
  });

  // Create inventory entry mutation
  const createMutation = useMutation({
    mutationFn: (data: InsertFreezerInventory) => 
      apiRequest("POST", "/api/freezer-inventory", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/freezer-inventory'] });
      setFormData({
        box: "",
        position: "",
        sampleId: "",
        type: "",
        dateIn: new Date().toISOString().split('T')[0],
        dateOut: "",
        notes: "",
      });
      toast({
        title: "Sample Added",
        description: "Sample has been added to freezer inventory successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Save Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Export mutation
  const exportMutation = useMutation({
    mutationFn: () => fetch('/api/export/freezer-inventory').then(r => r.text()),
    onSuccess: (csvData) => {
      downloadCSV(csvData, 'freezer_inventory.csv');
      toast({
        title: "Export Complete",
        description: "Freezer inventory data exported successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Export Failed",
        description: "Failed to export freezer inventory data.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    createMutation.mutate(formData);
  };

  const handleInputChange = (field: keyof InsertFreezerInventory, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const clearForm = () => {
    setFormData({
      box: "",
      position: "",
      sampleId: "",
      type: "",
      dateIn: new Date().toISOString().split('T')[0],
      dateOut: "",
      notes: "",
    });
  };

  // Filter inventory based on search
  const filteredInventory = inventory.filter(item => {
    const searchTerm = searchQuery.toLowerCase();
    return (
      item.box.toLowerCase().includes(searchTerm) ||
      item.sampleId.toLowerCase().includes(searchTerm) ||
      item.type?.toLowerCase().includes(searchTerm) ||
      item.position?.toLowerCase().includes(searchTerm)
    );
  });

  // Get sample status
  const getSampleStatus = (item: FreezerInventory) => {
    if (item.dateOut) {
      return <Badge className="bg-gray-100 text-gray-700">Removed</Badge>;
    }
    return <Badge className="bg-blue-100 text-blue-700">In Storage</Badge>;
  };

  if (isLoading) {
    return (
      <div className="space-y-8">
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-neutral-700 mb-2">Freezer Inventory</h2>
          <p className="text-neutral-500">Track sample locations and manage freezer storage organization with box and position tracking.</p>
        </div>
        <div className="animate-pulse space-y-4">
          <Card className="p-6">
            <div className="h-4 bg-gray-200 rounded w-1/4 mb-4"></div>
            <div className="grid grid-cols-3 gap-4">
              {[1, 2, 3].map(i => <div key={i} className="h-10 bg-gray-200 rounded"></div>)}
            </div>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-neutral-700 mb-2">Freezer Inventory</h2>
        <p className="text-neutral-500">Track sample locations and manage freezer storage organization with box and position tracking.</p>
      </div>

      {/* New Sample Form */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg font-semibold text-neutral-700">Add Sample to Inventory</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <Label htmlFor="box">Box</Label>
                <Input
                  id="box"
                  placeholder="e.g., Box-001"
                  value={formData.box}
                  onChange={(e) => handleInputChange('box', e.target.value)}
                  required
                />
              </div>
              <div>
                <Label htmlFor="position">Position</Label>
                <Input
                  id="position"
                  placeholder="e.g., A3"
                  value={formData.position}
                  onChange={(e) => handleInputChange('position', e.target.value)}
                />
              </div>
              <div>
                <Label htmlFor="sampleId">Sample ID</Label>
                <Input
                  id="sampleId"
                  placeholder="Unique sample identifier"
                  value={formData.sampleId}
                  onChange={(e) => handleInputChange('sampleId', e.target.value)}
                  required
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <Label htmlFor="type">Type</Label>
                <Input
                  id="type"
                  placeholder="e.g., Tissue lysate"
                  value={formData.type}
                  onChange={(e) => handleInputChange('type', e.target.value)}
                />
              </div>
              <div>
                <Label htmlFor="dateIn">Date In</Label>
                <Input
                  id="dateIn"
                  type="date"
                  value={formData.dateIn}
                  onChange={(e) => handleInputChange('dateIn', e.target.value)}
                  required
                />
              </div>
              <div>
                <Label htmlFor="dateOut">Date Out (optional)</Label>
                <Input
                  id="dateOut"
                  type="date"
                  value={formData.dateOut}
                  onChange={(e) => handleInputChange('dateOut', e.target.value)}
                />
              </div>
            </div>

            <div>
              <Label htmlFor="notes">Notes</Label>
              <Textarea
                id="notes"
                rows={3}
                placeholder="Sample details, preparation notes, experimental conditions..."
                value={formData.notes}
                onChange={(e) => handleInputChange('notes', e.target.value)}
              />
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <Button
                  type="submit"
                  disabled={createMutation.isPending}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  {createMutation.isPending ? (
                    <>
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
                      Adding...
                    </>
                  ) : (
                    <>
                      <Plus className="w-4 h-4 mr-2" />
                      Add Sample
                    </>
                  )}
                </Button>
                <Button
                  type="button"
                  onClick={() => exportMutation.mutate()}
                  disabled={exportMutation.isPending}
                  className="bg-green-600 hover:bg-green-700"
                >
                  {exportMutation.isPending ? (
                    <>
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
                      Exporting...
                    </>
                  ) : (
                    <>
                      <Download className="w-4 h-4 mr-2" />
                      Export CSV
                    </>
                  )}
                </Button>
              </div>
              <Button
                type="button"
                variant="ghost"
                onClick={clearForm}
                className="text-neutral-500 hover:text-neutral-700"
              >
                Clear Form
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>

      {/* Search */}
      <Card>
        <CardContent className="p-6">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-neutral-400 w-4 h-4" />
            <Input
              placeholder="Search by box, sample ID, type, or position..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
        </CardContent>
      </Card>

      {/* Freezer Inventory Table */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg font-semibold text-neutral-700">Freezer Inventory</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          {filteredInventory.length === 0 ? (
            <div className="text-center py-12">
              <Package className="mx-auto h-16 w-16 text-neutral-400 mb-4" />
              <p className="text-neutral-500">No samples in inventory</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-neutral-200">
                <thead className="bg-neutral-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Box</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Position</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Sample ID</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Type</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Date In</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Date Out</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Status</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Notes</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Actions</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-neutral-200">
                  {filteredInventory.map((item) => (
                    <tr key={item.id} className="hover:bg-neutral-50">
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-neutral-700">
                        <div className="flex items-center space-x-2">
                          <Snowflake className="w-4 h-4 text-blue-500" />
                          <span>{item.box}</span>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-600">
                        {item.position}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-600">
                        {item.sampleId}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-600">
                        {item.type}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-600">
                        {new Date(item.dateIn).toLocaleDateString()}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-600">
                        {item.dateOut ? new Date(item.dateOut).toLocaleDateString() : '-'}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-600">
                        {getSampleStatus(item)}
                      </td>
                      <td className="px-6 py-4 text-sm text-neutral-600 max-w-xs truncate">
                        {item.notes}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-500">
                        <div className="flex items-center space-x-2">
                          <Button variant="ghost" size="sm" className="text-blue-600 hover:text-blue-800">
                            <Edit className="w-4 h-4" />
                          </Button>
                          <Button variant="ghost" size="sm" className="text-red-600 hover:text-red-800">
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
