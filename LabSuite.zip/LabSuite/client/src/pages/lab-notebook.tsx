import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { downloadCSV } from "@/lib/csv-utils";
import { Search, Save, Upload, Download, Plus, Edit, Trash2, BookOpen } from "lucide-react";
import type { LabNotebookEntry, InsertLabNotebookEntry } from "@shared/schema";

export default function LabNotebook() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Form state
  const [formData, setFormData] = useState<InsertLabNotebookEntry>({
    date: new Date().toISOString().split('T')[0],
    title: "",
    experimentId: "",
    project: "",
    tags: "",
    content: "",
    links: "",
    author: "Dr. Sarah Chen",
    notes: "",
  });

  // Search and filter state
  const [searchQuery, setSearchQuery] = useState("");
  const [projectFilter, setProjectFilter] = useState("");

  // Fetch notebook entries
  const { data: entries = [], isLoading } = useQuery<LabNotebookEntry[]>({
    queryKey: ['/api/lab-notebook'],
  });

  // Create entry mutation
  const createMutation = useMutation({
    mutationFn: (data: InsertLabNotebookEntry) => 
      apiRequest("POST", "/api/lab-notebook", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/lab-notebook'] });
      setFormData({
        date: new Date().toISOString().split('T')[0],
        title: "",
        experimentId: "",
        project: "",
        tags: "",
        content: "",
        links: "",
        author: "Dr. Sarah Chen",
        notes: "",
      });
      toast({
        title: "Entry Saved",
        description: "Lab notebook entry has been saved successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Save Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Export mutation
  const exportMutation = useMutation({
    mutationFn: () => fetch('/api/export/lab-notebook').then(r => r.text()),
    onSuccess: (csvData) => {
      downloadCSV(csvData, 'lab_notebook.csv');
      toast({
        title: "Export Complete",
        description: "Lab notebook data exported successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Export Failed",
        description: "Failed to export lab notebook data.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    createMutation.mutate(formData);
  };

  const handleInputChange = (field: keyof InsertLabNotebookEntry, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const clearForm = () => {
    setFormData({
      date: new Date().toISOString().split('T')[0],
      title: "",
      experimentId: "",
      project: "",
      tags: "",
      content: "",
      links: "",
      author: "Dr. Sarah Chen",
      notes: "",
    });
  };

  // Filter entries based on search and project
  const filteredEntries = entries.filter(entry => {
    const matchesSearch = !searchQuery || 
      entry.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      entry.content.toLowerCase().includes(searchQuery.toLowerCase()) ||
      entry.tags?.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesProject = !projectFilter || projectFilter === 'all' || entry.project === projectFilter;
    
    return matchesSearch && matchesProject;
  });

  // Get unique projects for filter
  const projects = [...new Set(entries.map(e => e.project).filter(p => p && p.trim() !== ''))];

  if (isLoading) {
    return (
      <div className="space-y-8">
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-neutral-700 mb-2">Digital Lab Notebook</h2>
          <p className="text-neutral-500">Record experiments with markdown support, automatic timestamping, and searchable tags.</p>
        </div>
        <div className="animate-pulse space-y-4">
          <Card className="p-6">
            <div className="h-4 bg-gray-200 rounded w-1/4 mb-4"></div>
            <div className="space-y-3">
              <div className="h-4 bg-gray-200 rounded"></div>
              <div className="h-4 bg-gray-200 rounded"></div>
              <div className="h-24 bg-gray-200 rounded"></div>
            </div>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-neutral-700 mb-2">Digital Lab Notebook</h2>
        <p className="text-neutral-500">Record experiments with markdown support, automatic timestamping, and searchable tags.</p>
      </div>

      {/* New Entry Form */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg font-semibold text-neutral-700">New Notebook Entry</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <Label htmlFor="date">Date</Label>
                <Input
                  id="date"
                  type="date"
                  value={formData.date}
                  onChange={(e) => handleInputChange('date', e.target.value)}
                  required
                />
              </div>
              <div>
                <Label htmlFor="experimentId">Experiment ID</Label>
                <Input
                  id="experimentId"
                  placeholder="e.g., LGUT-042"
                  value={formData.experimentId}
                  onChange={(e) => handleInputChange('experimentId', e.target.value)}
                />
              </div>
              <div>
                <Label htmlFor="project">Project</Label>
                <Input
                  id="project"
                  placeholder="e.g., LeakyGut"
                  value={formData.project}
                  onChange={(e) => handleInputChange('project', e.target.value)}
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="title">Title</Label>
                <Input
                  id="title"
                  placeholder="e.g., LPS+ROT 2-week endpoint"
                  value={formData.title}
                  onChange={(e) => handleInputChange('title', e.target.value)}
                  required
                />
              </div>
              <div>
                <Label htmlFor="tags">Tags (comma-separated)</Label>
                <Input
                  id="tags"
                  placeholder="e.g., ELISA, histology, immunofluorescence"
                  value={formData.tags}
                  onChange={(e) => handleInputChange('tags', e.target.value)}
                />
              </div>
            </div>

            <div>
              <Label htmlFor="links">Links (comma-separated URLs or IDs)</Label>
              <Input
                id="links"
                placeholder="e.g., gdoc, drive links, slide IDs"
                value={formData.links}
                onChange={(e) => handleInputChange('links', e.target.value)}
              />
            </div>

            <div>
              <Label htmlFor="content">Content (Markdown supported)</Label>
              <Textarea
                id="content"
                rows={8}
                placeholder={`## Objective\nDescribe the purpose and hypothesis...\n\n## Methods\n1. Sample preparation\n2. Analysis protocol\n\n## Results\nKey findings and observations...\n\n## Conclusions\nSummary and next steps...`}
                value={formData.content}
                onChange={(e) => handleInputChange('content', e.target.value)}
                className="font-mono text-sm"
                required
              />
              <p className="text-xs text-neutral-500 mt-1">Supports markdown formatting: **bold**, *italic*, `code`, lists, headers, etc.</p>
            </div>

            <div>
              <Label htmlFor="notes">Private notes (not for export)</Label>
              <Textarea
                id="notes"
                rows={2}
                value={formData.notes}
                onChange={(e) => handleInputChange('notes', e.target.value)}
              />
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <Button
                  type="submit"
                  disabled={createMutation.isPending}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  {createMutation.isPending ? (
                    <>
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
                      Saving...
                    </>
                  ) : (
                    <>
                      <Save className="w-4 h-4 mr-2" />
                      Save Entry
                    </>
                  )}
                </Button>
                <Button
                  type="button"
                  onClick={() => exportMutation.mutate()}
                  disabled={exportMutation.isPending}
                  className="bg-green-600 hover:bg-green-700"
                >
                  {exportMutation.isPending ? (
                    <>
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
                      Exporting...
                    </>
                  ) : (
                    <>
                      <Download className="w-4 h-4 mr-2" />
                      Export CSV
                    </>
                  )}
                </Button>
              </div>
              <Button
                type="button"
                variant="ghost"
                onClick={clearForm}
                className="text-neutral-500 hover:text-neutral-700"
              >
                Clear Form
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>

      {/* Search and Filter */}
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center space-x-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-neutral-400 w-4 h-4" />
              <Input
                placeholder="Search entries by title, content, or tags..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={projectFilter} onValueChange={setProjectFilter}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="All Projects" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Projects</SelectItem>
                {projects.map(project => (
                  <SelectItem key={project} value={project || "Unknown"}>{project}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Notebook Entries */}
      <div className="space-y-6">
        {filteredEntries.length === 0 ? (
          <Card>
            <CardContent className="text-center py-12">
              <BookOpen className="mx-auto h-16 w-16 text-neutral-400 mb-4" />
              <p className="text-neutral-500">No notebook entries found</p>
            </CardContent>
          </Card>
        ) : (
          filteredEntries.map((entry) => (
            <Card key={entry.id}>
              <CardContent className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <div className="flex items-center space-x-3 mb-2">
                      <h4 className="text-lg font-semibold text-neutral-700">{entry.title}</h4>
                      {entry.experimentId && (
                        <Badge className="bg-blue-100 text-blue-700">
                          {entry.experimentId}
                        </Badge>
                      )}
                    </div>
                    <div className="flex items-center space-x-4 text-sm text-neutral-500">
                      <span>{new Date(entry.date).toLocaleDateString()}</span>
                      {entry.project && <span>Project: {entry.project}</span>}
                      <span>{entry.author}</span>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Button variant="ghost" size="sm" className="text-neutral-400 hover:text-neutral-600">
                      <Edit className="w-4 h-4" />
                    </Button>
                    <Button variant="ghost" size="sm" className="text-neutral-400 hover:text-red-600">
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
                
                {entry.tags && (
                  <div className="mb-4">
                    <div className="flex flex-wrap gap-2">
                      {entry.tags.split(',').map((tag, index) => (
                        <Badge key={index} variant="outline" className="bg-neutral-100 text-neutral-700">
                          {tag.trim()}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}

                <div className="prose prose-sm max-w-none text-neutral-600">
                  <pre className="whitespace-pre-wrap font-sans">{entry.content}</pre>
                </div>

                {entry.links && (
                  <div className="mt-4 pt-4 border-t border-neutral-200">
                    <p className="text-sm text-neutral-500">
                      <strong>Links:</strong> {entry.links}
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
}
