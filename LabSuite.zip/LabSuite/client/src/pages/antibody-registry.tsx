import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { downloadCSV } from "@/lib/csv-utils";
import { Search, Plus, Download, Edit, Trash2, TestTubeDiagonal } from "lucide-react";
import type { AntibodyRegistry, InsertAntibodyRegistry } from "@shared/schema";

export default function AntibodyRegistry() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Form state
  const [formData, setFormData] = useState<InsertAntibodyRegistry>({
    date: new Date().toISOString().split('T')[0],
    target: "",
    clone: "",
    host: "",
    reactivity: "",
    vendor: "",
    catalog: "",
    lot: "",
    dilution: "",
    application: "",
    storage: "",
    box: "",
    position: "",
    expiry: "",
    notes: "",
  });

  // Search state
  const [searchQuery, setSearchQuery] = useState("");

  // Fetch antibody registry
  const { data: antibodies = [], isLoading } = useQuery<AntibodyRegistry[]>({
    queryKey: ['/api/antibody-registry'],
  });

  // Create antibody entry mutation
  const createMutation = useMutation({
    mutationFn: (data: InsertAntibodyRegistry) => 
      apiRequest("POST", "/api/antibody-registry", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/antibody-registry'] });
      setFormData({
        date: new Date().toISOString().split('T')[0],
        target: "",
        clone: "",
        host: "",
        reactivity: "",
        vendor: "",
        catalog: "",
        lot: "",
        dilution: "",
        application: "",
        storage: "",
        box: "",
        position: "",
        expiry: "",
        notes: "",
      });
      toast({
        title: "Antibody Registered",
        description: "Antibody has been added to the registry successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Save Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Export mutation
  const exportMutation = useMutation({
    mutationFn: () => fetch('/api/export/antibody-registry').then(r => r.text()),
    onSuccess: (csvData) => {
      downloadCSV(csvData, 'antibody_registry.csv');
      toast({
        title: "Export Complete",
        description: "Antibody registry data exported successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Export Failed",
        description: "Failed to export antibody registry data.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    createMutation.mutate(formData);
  };

  const handleInputChange = (field: keyof InsertAntibodyRegistry, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const clearForm = () => {
    setFormData({
      date: new Date().toISOString().split('T')[0],
      target: "",
      clone: "",
      host: "",
      reactivity: "",
      vendor: "",
      catalog: "",
      lot: "",
      dilution: "",
      application: "",
      storage: "",
      box: "",
      position: "",
      expiry: "",
      notes: "",
    });
  };

  // Filter antibodies based on search
  const filteredAntibodies = antibodies.filter(antibody => {
    const searchTerm = searchQuery.toLowerCase();
    return (
      antibody.target.toLowerCase().includes(searchTerm) ||
      antibody.clone?.toLowerCase().includes(searchTerm) ||
      antibody.vendor?.toLowerCase().includes(searchTerm) ||
      antibody.catalog?.toLowerCase().includes(searchTerm)
    );
  });

  const isExpiringSoon = (expiryDate: string) => {
    if (!expiryDate) return false;
    const expiry = new Date(expiryDate);
    const today = new Date();
    const thirtyDaysFromNow = new Date(today.getTime() + 30 * 24 * 60 * 60 * 1000);
    return expiry <= thirtyDaysFromNow;
  };

  if (isLoading) {
    return (
      <div className="space-y-8">
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-neutral-700 mb-2">Antibody Registry</h2>
          <p className="text-neutral-500">Manage antibody inventory, track lot numbers, and monitor expiry dates.</p>
        </div>
        <div className="animate-pulse space-y-4">
          <Card className="p-6">
            <div className="h-4 bg-gray-200 rounded w-1/4 mb-4"></div>
            <div className="grid grid-cols-4 gap-4">
              {[1, 2, 3, 4].map(i => <div key={i} className="h-10 bg-gray-200 rounded"></div>)}
            </div>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-neutral-700 mb-2">Antibody Registry</h2>
        <p className="text-neutral-500">Manage antibody inventory, track lot numbers, and monitor expiry dates.</p>
      </div>

      {/* New Antibody Form */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg font-semibold text-neutral-700">Register New Antibody</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <div>
                <Label htmlFor="date">Date</Label>
                <Input
                  id="date"
                  type="date"
                  value={formData.date}
                  onChange={(e) => handleInputChange('date', e.target.value)}
                  required
                />
              </div>
              <div>
                <Label htmlFor="target">Target</Label>
                <Input
                  id="target"
                  placeholder="e.g., GFAP"
                  value={formData.target}
                  onChange={(e) => handleInputChange('target', e.target.value)}
                  required
                />
              </div>
              <div>
                <Label htmlFor="clone">Clone</Label>
                <Input
                  id="clone"
                  placeholder="e.g., GA5"
                  value={formData.clone}
                  onChange={(e) => handleInputChange('clone', e.target.value)}
                />
              </div>
              <div>
                <Label htmlFor="host">Host</Label>
                <Input
                  id="host"
                  placeholder="mouse/rabbit/goat"
                  value={formData.host}
                  onChange={(e) => handleInputChange('host', e.target.value)}
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <div>
                <Label htmlFor="reactivity">Reactivity</Label>
                <Input
                  id="reactivity"
                  placeholder="mouse/rat/human"
                  value={formData.reactivity}
                  onChange={(e) => handleInputChange('reactivity', e.target.value)}
                />
              </div>
              <div>
                <Label htmlFor="vendor">Vendor</Label>
                <Input
                  id="vendor"
                  placeholder="e.g., Cell Signaling"
                  value={formData.vendor}
                  onChange={(e) => handleInputChange('vendor', e.target.value)}
                />
              </div>
              <div>
                <Label htmlFor="catalog">Catalog</Label>
                <Input
                  id="catalog"
                  placeholder="Catalog number"
                  value={formData.catalog}
                  onChange={(e) => handleInputChange('catalog', e.target.value)}
                />
              </div>
              <div>
                <Label htmlFor="lot">Lot</Label>
                <Input
                  id="lot"
                  placeholder="Lot number"
                  value={formData.lot}
                  onChange={(e) => handleInputChange('lot', e.target.value)}
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <div>
                <Label htmlFor="dilution">Dilution</Label>
                <Input
                  id="dilution"
                  placeholder="1:1000"
                  value={formData.dilution}
                  onChange={(e) => handleInputChange('dilution', e.target.value)}
                />
              </div>
              <div>
                <Label htmlFor="application">Application</Label>
                <Input
                  id="application"
                  placeholder="WB/IF/IHC/ELISA"
                  value={formData.application}
                  onChange={(e) => handleInputChange('application', e.target.value)}
                />
              </div>
              <div>
                <Label htmlFor="storage">Storage</Label>
                <Input
                  id="storage"
                  placeholder="-20°C / 4°C"
                  value={formData.storage}
                  onChange={(e) => handleInputChange('storage', e.target.value)}
                />
              </div>
              <div>
                <Label htmlFor="expiry">Expiry</Label>
                <Input
                  id="expiry"
                  type="date"
                  value={formData.expiry}
                  onChange={(e) => handleInputChange('expiry', e.target.value)}
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="box">Box</Label>
                <Input
                  id="box"
                  placeholder="Storage box"
                  value={formData.box}
                  onChange={(e) => handleInputChange('box', e.target.value)}
                />
              </div>
              <div>
                <Label htmlFor="position">Position</Label>
                <Input
                  id="position"
                  placeholder="A3"
                  value={formData.position}
                  onChange={(e) => handleInputChange('position', e.target.value)}
                />
              </div>
            </div>

            <div>
              <Label htmlFor="notes">Notes</Label>
              <Textarea
                id="notes"
                rows={2}
                placeholder="Additional notes about the antibody..."
                value={formData.notes}
                onChange={(e) => handleInputChange('notes', e.target.value)}
              />
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <Button
                  type="submit"
                  disabled={createMutation.isPending}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  {createMutation.isPending ? (
                    <>
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
                      Registering...
                    </>
                  ) : (
                    <>
                      <Plus className="w-4 h-4 mr-2" />
                      Register Antibody
                    </>
                  )}
                </Button>
                <Button
                  type="button"
                  onClick={() => exportMutation.mutate()}
                  disabled={exportMutation.isPending}
                  className="bg-green-600 hover:bg-green-700"
                >
                  {exportMutation.isPending ? (
                    <>
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
                      Exporting...
                    </>
                  ) : (
                    <>
                      <Download className="w-4 h-4 mr-2" />
                      Export CSV
                    </>
                  )}
                </Button>
              </div>
              <Button
                type="button"
                variant="ghost"
                onClick={clearForm}
                className="text-neutral-500 hover:text-neutral-700"
              >
                Clear Form
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>

      {/* Search */}
      <Card>
        <CardContent className="p-6">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-neutral-400 w-4 h-4" />
            <Input
              placeholder="Search antibodies by target, clone, vendor, or catalog..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
        </CardContent>
      </Card>

      {/* Antibody Registry Table */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg font-semibold text-neutral-700">Antibody Registry</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          {filteredAntibodies.length === 0 ? (
            <div className="text-center py-12">
              <TestTubeDiagonal className="mx-auto h-16 w-16 text-neutral-400 mb-4" />
              <p className="text-neutral-500">No antibodies registered</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-neutral-200">
                <thead className="bg-neutral-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Date</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Target</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Clone</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Host</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Vendor</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Catalog</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Lot</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Dilution</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Application</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Storage</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Expiry</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Actions</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-neutral-200">
                  {filteredAntibodies.map((antibody) => (
                    <tr key={antibody.id} className="hover:bg-neutral-50">
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-600">
                        {new Date(antibody.date).toLocaleDateString()}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-neutral-700">
                        {antibody.target}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-600">
                        {antibody.clone}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-600">
                        {antibody.host}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-600">
                        {antibody.vendor}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-600">
                        {antibody.catalog}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-600">
                        {antibody.lot}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-600">
                        {antibody.dilution}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-600">
                        {antibody.application}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-600">
                        {antibody.storage}
                        {antibody.box && antibody.position && (
                          <div className="text-xs text-neutral-500">
                            {antibody.box} {antibody.position}
                          </div>
                        )}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-600">
                        {antibody.expiry ? (
                          <div className="flex items-center space-x-2">
                            <span>{new Date(antibody.expiry).toLocaleDateString()}</span>
                            {isExpiringSoon(antibody.expiry) && (
                              <Badge className="bg-red-100 text-red-700 text-xs">
                                Expiring Soon
                              </Badge>
                            )}
                          </div>
                        ) : (
                          '-'
                        )}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-500">
                        <div className="flex items-center space-x-2">
                          <Button variant="ghost" size="sm" className="text-blue-600 hover:text-blue-800">
                            <Edit className="w-4 h-4" />
                          </Button>
                          <Button variant="ghost" size="sm" className="text-red-600 hover:text-red-800">
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
