import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { downloadCSV } from "@/lib/csv-utils";
import { Search, Plus, Download, Edit, Trash2, PawPrint } from "lucide-react";
import type { AnimalLog, InsertAnimalLog } from "@shared/schema";

export default function AnimalLog() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Form state
  const [formData, setFormData] = useState<InsertAnimalLog>({
    date: new Date().toISOString().split('T')[0],
    mouseId: "",
    strain: "",
    sex: "F",
    dateOfBirth: "",
    ageWeeks: null,
    treatment: "",
    weight: null,
    observations: "",
  });

  // Search and filter state
  const [searchQuery, setSearchQuery] = useState("");
  const [strainFilter, setStrainFilter] = useState("");
  const [treatmentFilter, setTreatmentFilter] = useState("");

  // Fetch animal logs
  const { data: logs = [], isLoading } = useQuery<AnimalLog[]>({
    queryKey: ['/api/animal-logs'],
  });

  // Create log mutation
  const createMutation = useMutation({
    mutationFn: (data: InsertAnimalLog) => 
      apiRequest("POST", "/api/animal-logs", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/animal-logs'] });
      setFormData({
        date: new Date().toISOString().split('T')[0],
        mouseId: "",
        strain: "",
        sex: "F",
        dateOfBirth: "",
        ageWeeks: null,
        treatment: "",
        weight: null,
        observations: "",
      });
      toast({
        title: "Entry Added",
        description: "Animal log entry has been added successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Save Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Export mutation
  const exportMutation = useMutation({
    mutationFn: () => fetch('/api/export/animal-logs').then(r => r.text()),
    onSuccess: (csvData) => {
      downloadCSV(csvData, 'animal_logs.csv');
      toast({
        title: "Export Complete",
        description: "Animal log data exported successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Export Failed",
        description: "Failed to export animal log data.",
        variant: "destructive",
      });
    },
  });

  const calculateAge = (dob: string, currentDate: string = formData.date) => {
    if (!dob || !currentDate) return null;
    
    const dobDate = new Date(dob);
    const currentDateObj = new Date(currentDate);
    const diffTime = Math.abs(currentDateObj.getTime() - dobDate.getTime());
    const diffWeeks = diffTime / (1000 * 60 * 60 * 24 * 7);
    
    return parseFloat(diffWeeks.toFixed(1));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const ageWeeks = calculateAge(formData.dateOfBirth || '', formData.date);
    createMutation.mutate({ ...formData, ageWeeks });
  };

  const handleInputChange = (field: keyof InsertAnimalLog, value: string | number | null) => {
    setFormData(prev => {
      const updated = { ...prev, [field]: value };
      
      // Auto-calculate age when date of birth or date changes
      if ((field === 'dateOfBirth' || field === 'date') && updated.dateOfBirth) {
        updated.ageWeeks = calculateAge(updated.dateOfBirth, updated.date);
      }
      
      return updated;
    });
  };

  const clearForm = () => {
    setFormData({
      date: new Date().toISOString().split('T')[0],
      mouseId: "",
      strain: "",
      sex: "F",
      dateOfBirth: "",
      ageWeeks: null,
      treatment: "",
      weight: null,
      observations: "",
    });
  };

  // Filter logs based on search and filters
  const filteredLogs = logs.filter(log => {
    const matchesSearch = !searchQuery || 
      log.mouseId.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesStrain = !strainFilter || strainFilter === 'all' || log.strain === strainFilter;
    const matchesTreatment = !treatmentFilter || treatmentFilter === 'all' || log.treatment?.includes(treatmentFilter);
    
    return matchesSearch && matchesStrain && matchesTreatment;
  });

  // Get unique values for filters
  const strains = [...new Set(logs.map(l => l.strain).filter(s => s && s.trim() !== ''))];
  const treatments = [...new Set(logs.map(l => l.treatment).filter(t => t && t.trim() !== ''))];

  if (isLoading) {
    return (
      <div className="space-y-8">
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-neutral-700 mb-2">Animal Management Log</h2>
          <p className="text-neutral-500">Track animal metadata, treatments, weights, and health observations with automatic age calculations.</p>
        </div>
        <div className="animate-pulse space-y-4">
          <Card className="p-6">
            <div className="h-4 bg-gray-200 rounded w-1/4 mb-4"></div>
            <div className="grid grid-cols-4 gap-4">
              {[1, 2, 3, 4].map(i => <div key={i} className="h-10 bg-gray-200 rounded"></div>)}
            </div>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-neutral-700 mb-2">Animal Management Log</h2>
        <p className="text-neutral-500">Track animal metadata, treatments, weights, and health observations with automatic age calculations.</p>
      </div>

      {/* New Animal Entry Form */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg font-semibold text-neutral-700">Log Animal Data</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <div>
                <Label htmlFor="date">Date</Label>
                <Input
                  id="date"
                  type="date"
                  value={formData.date}
                  onChange={(e) => handleInputChange('date', e.target.value)}
                  required
                />
              </div>
              <div>
                <Label htmlFor="mouseId">Mouse ID</Label>
                <Input
                  id="mouseId"
                  placeholder="e.g., M001"
                  value={formData.mouseId}
                  onChange={(e) => handleInputChange('mouseId', e.target.value)}
                  required
                />
              </div>
              <div>
                <Label htmlFor="strain">Strain</Label>
                <Select value={formData.strain} onValueChange={(value) => handleInputChange('strain', value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select strain..." />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="C57BL/6J">C57BL/6J</SelectItem>
                    <SelectItem value="BALB/c">BALB/c</SelectItem>
                    <SelectItem value="129S1/SvImJ">129S1/SvImJ</SelectItem>
                    <SelectItem value="FVB/NJ">FVB/NJ</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="sex">Sex</Label>
                <Select value={formData.sex} onValueChange={(value) => handleInputChange('sex', value)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="F">Female</SelectItem>
                    <SelectItem value="M">Male</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <div>
                <Label htmlFor="dateOfBirth">Date of Birth</Label>
                <Input
                  id="dateOfBirth"
                  type="date"
                  value={formData.dateOfBirth}
                  onChange={(e) => handleInputChange('dateOfBirth', e.target.value)}
                />
              </div>
              <div>
                <Label htmlFor="ageWeeks">Age (weeks)</Label>
                <Input
                  id="ageWeeks"
                  type="text"
                  value={formData.ageWeeks?.toString() || ''}
                  readOnly
                  placeholder="Auto-calculated"
                  className="bg-neutral-50 text-neutral-600"
                />
              </div>
              <div>
                <Label htmlFor="weight">Weight (g)</Label>
                <Input
                  id="weight"
                  type="number"
                  step="0.1"
                  placeholder="e.g., 25.3"
                  value={formData.weight?.toString() || ''}
                  onChange={(e) => handleInputChange('weight', e.target.value ? parseFloat(e.target.value) : null)}
                />
              </div>
              <div>
                <Label htmlFor="treatment">Treatment Group</Label>
                <Input
                  id="treatment"
                  placeholder="e.g., LPS 1mg/kg"
                  value={formData.treatment}
                  onChange={(e) => handleInputChange('treatment', e.target.value)}
                />
              </div>
            </div>

            <div>
              <Label htmlFor="observations">Health & Observations</Label>
              <Textarea
                id="observations"
                rows={3}
                placeholder="Health status, behavioral observations, procedures performed..."
                value={formData.observations}
                onChange={(e) => handleInputChange('observations', e.target.value)}
              />
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <Button
                  type="submit"
                  disabled={createMutation.isPending}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  {createMutation.isPending ? (
                    <>
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
                      Adding...
                    </>
                  ) : (
                    <>
                      <Plus className="w-4 h-4 mr-2" />
                      Add Entry
                    </>
                  )}
                </Button>
                <Button
                  type="button"
                  onClick={() => exportMutation.mutate()}
                  disabled={exportMutation.isPending}
                  className="bg-green-600 hover:bg-green-700"
                >
                  {exportMutation.isPending ? (
                    <>
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
                      Exporting...
                    </>
                  ) : (
                    <>
                      <Download className="w-4 h-4 mr-2" />
                      Export CSV
                    </>
                  )}
                </Button>
              </div>
              <Button
                type="button"
                variant="ghost"
                onClick={clearForm}
                className="text-neutral-500 hover:text-neutral-700"
              >
                Clear Form
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>

      {/* Search and Filter */}
      <Card>
        <CardContent className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-neutral-400 w-4 h-4" />
              <Input
                placeholder="Search by Mouse ID..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={strainFilter} onValueChange={setStrainFilter}>
              <SelectTrigger>
                <SelectValue placeholder="All Strains" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Strains</SelectItem>
                {strains.map(strain => (
                  <SelectItem key={strain} value={strain || "Unknown"}>{strain}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={treatmentFilter} onValueChange={setTreatmentFilter}>
              <SelectTrigger>
                <SelectValue placeholder="All Treatments" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Treatments</SelectItem>
                {treatments.map(treatment => (
                  <SelectItem key={treatment} value={treatment || "Unknown"}>{treatment}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Animal Data Table */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg font-semibold text-neutral-700">Animal Records</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          {filteredLogs.length === 0 ? (
            <div className="text-center py-12">
              <PawPrint className="mx-auto h-16 w-16 text-neutral-400 mb-4" />
              <p className="text-neutral-500">No animal records found</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-neutral-200">
                <thead className="bg-neutral-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Date</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Mouse ID</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Strain</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Sex</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Age (weeks)</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Weight (g)</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Treatment</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Observations</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Actions</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-neutral-200">
                  {filteredLogs.map((log) => (
                    <tr key={log.id} className="hover:bg-neutral-50">
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-600">
                        {new Date(log.date).toLocaleDateString()}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-neutral-700">
                        {log.mouseId}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-600">
                        {log.strain}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-600">
                        {log.sex}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-600">
                        {log.ageWeeks}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-600">
                        {log.weight}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-600">
                        {log.treatment && (
                          <Badge className="bg-blue-100 text-blue-700">
                            {log.treatment}
                          </Badge>
                        )}
                      </td>
                      <td className="px-6 py-4 text-sm text-neutral-600 max-w-xs truncate">
                        {log.observations}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-500">
                        <div className="flex items-center space-x-2">
                          <Button variant="ghost" size="sm" className="text-blue-600 hover:text-blue-800">
                            <Edit className="w-4 h-4" />
                          </Button>
                          <Button variant="ghost" size="sm" className="text-red-600 hover:text-red-800">
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
