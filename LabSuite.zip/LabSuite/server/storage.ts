import { 
  type User, 
  type InsertUser,
  type LabNotebookEntry,
  type InsertLabNotebookEntry,
  type AnimalLog,
  type InsertAnimalLog,
  type ExperimentSchedule,
  type InsertExperimentSchedule,
  type AntibodyRegistry,
  type InsertAntibodyRegistry,
  type SlideRegistry,
  type InsertSlideRegistry,
  type FreezerInventory,
  type InsertFreezerInventory,
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Lab Notebook
  getLabNotebookEntries(): Promise<LabNotebookEntry[]>;
  createLabNotebookEntry(entry: InsertLabNotebookEntry): Promise<LabNotebookEntry>;
  updateLabNotebookEntry(id: string, entry: Partial<InsertLabNotebookEntry>): Promise<LabNotebookEntry | undefined>;
  deleteLabNotebookEntry(id: string): Promise<boolean>;

  // Animal Logs
  getAnimalLogs(): Promise<AnimalLog[]>;
  createAnimalLog(log: InsertAnimalLog): Promise<AnimalLog>;
  updateAnimalLog(id: string, log: Partial<InsertAnimalLog>): Promise<AnimalLog | undefined>;
  deleteAnimalLog(id: string): Promise<boolean>;

  // Experiment Schedules
  getExperimentSchedules(): Promise<ExperimentSchedule[]>;
  createExperimentSchedule(schedule: InsertExperimentSchedule): Promise<ExperimentSchedule>;
  updateExperimentSchedule(id: string, schedule: Partial<InsertExperimentSchedule>): Promise<ExperimentSchedule | undefined>;
  deleteExperimentSchedule(id: string): Promise<boolean>;

  // Antibody Registry
  getAntibodyRegistry(): Promise<AntibodyRegistry[]>;
  createAntibodyRegistryEntry(entry: InsertAntibodyRegistry): Promise<AntibodyRegistry>;
  updateAntibodyRegistryEntry(id: string, entry: Partial<InsertAntibodyRegistry>): Promise<AntibodyRegistry | undefined>;
  deleteAntibodyRegistryEntry(id: string): Promise<boolean>;

  // Slide Registry
  getSlideRegistry(): Promise<SlideRegistry[]>;
  createSlideRegistryEntry(entry: InsertSlideRegistry): Promise<SlideRegistry>;
  updateSlideRegistryEntry(id: string, entry: Partial<InsertSlideRegistry>): Promise<SlideRegistry | undefined>;
  deleteSlideRegistryEntry(id: string): Promise<boolean>;

  // Freezer Inventory
  getFreezerInventory(): Promise<FreezerInventory[]>;
  createFreezerInventoryEntry(entry: InsertFreezerInventory): Promise<FreezerInventory>;
  updateFreezerInventoryEntry(id: string, entry: Partial<InsertFreezerInventory>): Promise<FreezerInventory | undefined>;
  deleteFreezerInventoryEntry(id: string): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private labNotebookEntries: Map<string, LabNotebookEntry>;
  private animalLogs: Map<string, AnimalLog>;
  private experimentSchedules: Map<string, ExperimentSchedule>;
  private antibodyRegistry: Map<string, AntibodyRegistry>;
  private slideRegistry: Map<string, SlideRegistry>;
  private freezerInventory: Map<string, FreezerInventory>;

  constructor() {
    this.users = new Map();
    this.labNotebookEntries = new Map();
    this.animalLogs = new Map();
    this.experimentSchedules = new Map();
    this.antibodyRegistry = new Map();
    this.slideRegistry = new Map();
    this.freezerInventory = new Map();
  }

  // User methods
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Lab Notebook methods
  async getLabNotebookEntries(): Promise<LabNotebookEntry[]> {
    return Array.from(this.labNotebookEntries.values()).sort((a, b) => 
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }

  async createLabNotebookEntry(entry: InsertLabNotebookEntry): Promise<LabNotebookEntry> {
    const id = randomUUID();
    const newEntry: LabNotebookEntry = {
      ...entry,
      id,
      createdAt: new Date(),
      experimentId: entry.experimentId ?? null,
      project: entry.project ?? null,
      tags: entry.tags ?? null,
      links: entry.links ?? null,
      notes: entry.notes ?? null,
    };
    this.labNotebookEntries.set(id, newEntry);
    return newEntry;
  }

  async updateLabNotebookEntry(id: string, entry: Partial<InsertLabNotebookEntry>): Promise<LabNotebookEntry | undefined> {
    const existing = this.labNotebookEntries.get(id);
    if (!existing) return undefined;
    
    const updated = { ...existing, ...entry };
    this.labNotebookEntries.set(id, updated);
    return updated;
  }

  async deleteLabNotebookEntry(id: string): Promise<boolean> {
    return this.labNotebookEntries.delete(id);
  }

  // Animal Log methods
  async getAnimalLogs(): Promise<AnimalLog[]> {
    return Array.from(this.animalLogs.values()).sort((a, b) => 
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }

  async createAnimalLog(log: InsertAnimalLog): Promise<AnimalLog> {
    const id = randomUUID();
    const newLog: AnimalLog = {
      ...log,
      id,
      createdAt: new Date(),
      dateOfBirth: log.dateOfBirth ?? null,
      ageWeeks: log.ageWeeks ?? null,
      treatment: log.treatment ?? null,
      weight: log.weight ?? null,
      observations: log.observations ?? null,
    };
    this.animalLogs.set(id, newLog);
    return newLog;
  }

  async updateAnimalLog(id: string, log: Partial<InsertAnimalLog>): Promise<AnimalLog | undefined> {
    const existing = this.animalLogs.get(id);
    if (!existing) return undefined;
    
    const updated = { ...existing, ...log };
    this.animalLogs.set(id, updated);
    return updated;
  }

  async deleteAnimalLog(id: string): Promise<boolean> {
    return this.animalLogs.delete(id);
  }

  // Experiment Schedule methods
  async getExperimentSchedules(): Promise<ExperimentSchedule[]> {
    return Array.from(this.experimentSchedules.values()).sort((a, b) => 
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }

  async createExperimentSchedule(schedule: InsertExperimentSchedule): Promise<ExperimentSchedule> {
    const id = randomUUID();
    const newSchedule: ExperimentSchedule = {
      ...schedule,
      id,
      createdAt: new Date(),
      notes: schedule.notes ?? null,
      pi: schedule.pi ?? null,
      operator: schedule.operator ?? null,
      species: schedule.species ?? null,
      nPlanned: schedule.nPlanned ?? null,
      groups: schedule.groups ?? null,
      due: schedule.due ?? null,
    };
    this.experimentSchedules.set(id, newSchedule);
    return newSchedule;
  }

  async updateExperimentSchedule(id: string, schedule: Partial<InsertExperimentSchedule>): Promise<ExperimentSchedule | undefined> {
    const existing = this.experimentSchedules.get(id);
    if (!existing) return undefined;
    
    const updated = { ...existing, ...schedule };
    this.experimentSchedules.set(id, updated);
    return updated;
  }

  async deleteExperimentSchedule(id: string): Promise<boolean> {
    return this.experimentSchedules.delete(id);
  }

  // Antibody Registry methods
  async getAntibodyRegistry(): Promise<AntibodyRegistry[]> {
    return Array.from(this.antibodyRegistry.values()).sort((a, b) => 
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }

  async createAntibodyRegistryEntry(entry: InsertAntibodyRegistry): Promise<AntibodyRegistry> {
    const id = randomUUID();
    const newEntry: AntibodyRegistry = {
      ...entry,
      id,
      createdAt: new Date(),
      notes: entry.notes ?? null,
      clone: entry.clone ?? null,
      host: entry.host ?? null,
      reactivity: entry.reactivity ?? null,
      vendor: entry.vendor ?? null,
      catalog: entry.catalog ?? null,
      lot: entry.lot ?? null,
      concentration: entry.concentration ?? null,
      storage: entry.storage ?? null,
      expiry: entry.expiry ?? null,
    };
    this.antibodyRegistry.set(id, newEntry);
    return newEntry;
  }

  async updateAntibodyRegistryEntry(id: string, entry: Partial<InsertAntibodyRegistry>): Promise<AntibodyRegistry | undefined> {
    const existing = this.antibodyRegistry.get(id);
    if (!existing) return undefined;
    
    const updated = { ...existing, ...entry };
    this.antibodyRegistry.set(id, updated);
    return updated;
  }

  async deleteAntibodyRegistryEntry(id: string): Promise<boolean> {
    return this.antibodyRegistry.delete(id);
  }

  // Slide Registry methods
  async getSlideRegistry(): Promise<SlideRegistry[]> {
    return Array.from(this.slideRegistry.values()).sort((a, b) => 
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }

  async createSlideRegistryEntry(entry: InsertSlideRegistry): Promise<SlideRegistry> {
    const id = randomUUID();
    const newEntry: SlideRegistry = {
      ...entry,
      id,
      createdAt: new Date(),
      notes: entry.notes ?? null,
      box: entry.box ?? null,
      region: entry.region ?? null,
      thickness: entry.thickness ?? null,
      stains: entry.stains ?? null,
    };
    this.slideRegistry.set(id, newEntry);
    return newEntry;
  }

  async updateSlideRegistryEntry(id: string, entry: Partial<InsertSlideRegistry>): Promise<SlideRegistry | undefined> {
    const existing = this.slideRegistry.get(id);
    if (!existing) return undefined;
    
    const updated = { ...existing, ...entry };
    this.slideRegistry.set(id, updated);
    return updated;
  }

  async deleteSlideRegistryEntry(id: string): Promise<boolean> {
    return this.slideRegistry.delete(id);
  }

  // Freezer Inventory methods
  async getFreezerInventory(): Promise<FreezerInventory[]> {
    return Array.from(this.freezerInventory.values()).sort((a, b) => 
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }

  async createFreezerInventoryEntry(entry: InsertFreezerInventory): Promise<FreezerInventory> {
    const id = randomUUID();
    const newEntry: FreezerInventory = {
      ...entry,
      id,
      createdAt: new Date(),
      notes: entry.notes ?? null,
      type: entry.type ?? null,
      position: entry.position ?? null,
      dateOut: entry.dateOut ?? null,
    };
    this.freezerInventory.set(id, newEntry);
    return newEntry;
  }

  async updateFreezerInventoryEntry(id: string, entry: Partial<InsertFreezerInventory>): Promise<FreezerInventory | undefined> {
    const existing = this.freezerInventory.get(id);
    if (!existing) return undefined;
    
    const updated = { ...existing, ...entry };
    this.freezerInventory.set(id, updated);
    return updated;
  }

  async deleteFreezerInventoryEntry(id: string): Promise<boolean> {
    return this.freezerInventory.delete(id);
  }
}

export const storage = new MemStorage();
