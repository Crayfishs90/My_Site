import { useState, useRef } from "react";
import { useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { Upload, Play, BarChart3 } from "lucide-react";
import StatsDisplay from "@/components/ui/stats-display";

export default function Statistics() {
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [csvFile, setCsvFile] = useState<File | null>(null);
  const [csvHeaders, setCsvHeaders] = useState<string[]>([]);
  const [groupColumn, setGroupColumn] = useState<string>("");
  const [valueColumn, setValueColumn] = useState<string>("");
  const [testType, setTestType] = useState<string>("anova");
  const [results, setResults] = useState<any>(null);

  const analysisMutation = useMutation({
    mutationFn: async (formData: FormData) => {
      const response = await fetch('/api/run-stats', {
        method: 'POST',
        body: formData,
      });
      
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Analysis failed');
      }
      
      return response.json();
    },
    onSuccess: (data) => {
      setResults(data);
      toast({
        title: "Analysis Complete",
        description: "Statistical analysis has been completed successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Analysis Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setCsvFile(file);
      
      // Parse CSV headers
      const reader = new FileReader();
      reader.onload = (e) => {
        const text = e.target?.result as string;
        const firstLine = text.split('\n')[0];
        const headers = firstLine.split(',').map(h => h.trim().replace(/"/g, ''));
        setCsvHeaders(headers);
        
        // Auto-select common column names
        if (headers.includes('Group')) setGroupColumn('Group');
        if (headers.includes('group')) setGroupColumn('group');
        if (headers.includes('Value')) setValueColumn('Value');
        if (headers.includes('value')) setValueColumn('value');
        if (headers.includes('measurement')) setValueColumn('measurement');
      };
      reader.readAsText(file);
    }
  };

  const handleAnalysis = () => {
    if (!csvFile || !groupColumn || !valueColumn) {
      toast({
        title: "Missing Information",
        description: "Please upload a CSV file and select both group and value columns.",
        variant: "destructive",
      });
      return;
    }

    const formData = new FormData();
    formData.append('csvFile', csvFile);
    formData.append('groupColumn', groupColumn);
    formData.append('valueColumn', valueColumn);
    formData.append('testType', testType);

    analysisMutation.mutate(formData);
  };

  return (
    <div className="space-y-8">
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-neutral-700 mb-2">Statistical Analysis Runner</h2>
        <p className="text-neutral-500">Upload CSV data and run statistical tests with automated post-hoc analysis.</p>
      </div>

      {/* File Upload & Configuration */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg font-semibold text-neutral-700">Data Upload & Configuration</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* File Upload */}
          <div>
            <Label className="text-sm font-medium text-neutral-700">CSV Data File</Label>
            <div 
              className="border-2 border-dashed border-neutral-300 rounded-lg p-6 text-center hover:border-blue-400 transition-colors cursor-pointer mt-2"
              onClick={() => fileInputRef.current?.click()}
            >
              <Upload className="mx-auto h-12 w-12 text-neutral-400 mb-4" />
              <p className="text-neutral-600 mb-1">
                {csvFile ? csvFile.name : "Click to upload or drag and drop"}
              </p>
              <p className="text-xs text-neutral-500">CSV files only</p>
              <input
                type="file"
                ref={fileInputRef}
                className="hidden"
                accept=".csv"
                onChange={handleFileChange}
              />
            </div>
          </div>

          {/* Column Selection */}
          {csvHeaders.length > 0 && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <Label className="text-sm font-medium text-neutral-700">Group Column</Label>
                <Select value={groupColumn} onValueChange={setGroupColumn}>
                  <SelectTrigger className="mt-2">
                    <SelectValue placeholder="Select group column..." />
                  </SelectTrigger>
                  <SelectContent>
                    {csvHeaders.filter(header => header.trim()).map(header => (
                      <SelectItem key={header} value={header}>{header}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label className="text-sm font-medium text-neutral-700">Value Column</Label>
                <Select value={valueColumn} onValueChange={setValueColumn}>
                  <SelectTrigger className="mt-2">
                    <SelectValue placeholder="Select value column..." />
                  </SelectTrigger>
                  <SelectContent>
                    {csvHeaders.filter(header => header.trim()).map(header => (
                      <SelectItem key={header} value={header}>{header}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label className="text-sm font-medium text-neutral-700">Statistical Test</Label>
                <Select value={testType} onValueChange={setTestType}>
                  <SelectTrigger className="mt-2">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="ttest">t-test (2 groups)</SelectItem>
                    <SelectItem value="anova">One-way ANOVA + Tukey HSD</SelectItem>
                    <SelectItem value="kruskal">Kruskal-Wallis + Dunn</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          )}

          <Button 
            onClick={handleAnalysis}
            disabled={analysisMutation.isPending || !csvFile || !groupColumn || !valueColumn}
            className="bg-blue-600 hover:bg-blue-700"
          >
            {analysisMutation.isPending ? (
              <>
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
                Running Analysis...
              </>
            ) : (
              <>
                <Play className="w-4 h-4 mr-2" />
                Run Analysis
              </>
            )}
          </Button>
        </CardContent>
      </Card>

      {/* Results Section */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg font-semibold text-neutral-700">Analysis Results</CardTitle>
        </CardHeader>
        <CardContent>
          {results ? (
            <StatsDisplay results={results} />
          ) : (
            <div className="text-center py-12 text-neutral-500">
              <BarChart3 className="mx-auto h-16 w-16 text-neutral-400 mb-4" />
              <p>Upload data and run analysis to view results</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
