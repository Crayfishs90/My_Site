import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Dashboard from "@/pages/dashboard";
import Statistics from "@/pages/statistics";
import LabNotebook from "@/pages/lab-notebook";
import AnimalLog from "@/pages/animal-log";
import ExperimentScheduler from "@/pages/experiment-scheduler";
import AntibodyRegistry from "@/pages/antibody-registry";
import SlideRegistry from "@/pages/slide-registry";
import FreezerInventory from "@/pages/freezer-inventory";
import DilutionCalculator from "@/pages/dilution-calculator";
import Header from "@/components/layout/header";
import Navigation from "@/components/layout/navigation";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Dashboard} />
      <Route path="/statistics" component={Statistics} />
      <Route path="/lab-notebook" component={LabNotebook} />
      <Route path="/animal-log" component={AnimalLog} />
      <Route path="/experiment-scheduler" component={ExperimentScheduler} />
      <Route path="/antibody-registry" component={AntibodyRegistry} />
      <Route path="/slide-registry" component={SlideRegistry} />
      <Route path="/freezer-inventory" component={FreezerInventory} />
      <Route path="/dilution-calculator" component={DilutionCalculator} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <div className="min-h-screen bg-neutral-50">
          <Header />
          <Navigation />
          <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <Router />
          </main>
        </div>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
