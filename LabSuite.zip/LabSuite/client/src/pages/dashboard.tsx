import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import {
  FlaskConical,
  PawPrint,
  BookOpen,
  Snowflake,
  BarChart3,
  Calendar,
  TestTubeDiagonal,
  Calculator,
  ArrowRight,
  TrendingUp,
} from "lucide-react";

export default function Dashboard() {
  const [, navigate] = useLocation();

  // Fetch dashboard statistics
  const { data: stats, isLoading } = useQuery({
    queryKey: ['/api/dashboard-stats'],
    queryFn: async () => {
      // Calculate stats from different endpoints
      const [notebooks, animals, experiments, inventory] = await Promise.all([
        fetch('/api/lab-notebook').then(r => r.json()).catch(() => []),
        fetch('/api/animal-logs').then(r => r.json()).catch(() => []),
        fetch('/api/experiment-schedules').then(r => r.json()).catch(() => []),
        fetch('/api/freezer-inventory').then(r => r.json()).catch(() => [])
      ]);
      
      return {
        activeExperiments: experiments.filter((e: any) => e.status === 'active').length,
        animalsTracked: animals.length,
        notebookEntries: notebooks.length,
        freezerSamples: inventory.length
      };
    }
  });

  const toolCards = [
    {
      title: "Statistical Analysis",
      description: "Run t-tests, ANOVA, and Kruskal-Wallis tests on your data with automated post-hoc analysis.",
      icon: BarChart3,
      badge: "Analysis",
      badgeColor: "bg-blue-100 text-blue-700",
      iconColor: "bg-blue-100 text-blue-600",
      path: "/statistics",
    },
    {
      title: "Digital Lab Notebook",
      description: "Record experiments with markdown support, tags, and automatic timestamping for compliance.",
      icon: BookOpen,
      badge: "Documentation",
      badgeColor: "bg-green-100 text-green-700",
      iconColor: "bg-green-100 text-green-600",
      path: "/lab-notebook",
    },
    {
      title: "Animal Management",
      description: "Track animal metadata, treatments, weights, and automatically calculate ages for research compliance.",
      icon: PawPrint,
      badge: "Research",
      badgeColor: "bg-yellow-100 text-yellow-700",
      iconColor: "bg-yellow-100 text-yellow-600",
      path: "/animal-log",
    },
    {
      title: "Experiment Scheduler",
      description: "Plan and track experiment timelines, assign resources, and monitor progress across projects.",
      icon: Calendar,
      badge: "Planning",
      badgeColor: "bg-purple-100 text-purple-700",
      iconColor: "bg-purple-100 text-purple-600",
      path: "/experiment-scheduler",
    },
    {
      title: "Antibody & Slide Registry",
      description: "Manage antibody inventory, track lot numbers, and maintain slide registry for histology work.",
      icon: TestTubeDiagonal,
      badge: "Reagents",
      badgeColor: "bg-red-100 text-red-700",
      iconColor: "bg-red-100 text-red-600",
      path: "/antibody-registry",
    },
    {
      title: "Laboratory Calculators",
      description: "Dilution calculators, freezer inventory management, and other essential lab utilities.",
      icon: Calculator,
      badge: "Utilities",
      badgeColor: "bg-gray-100 text-gray-700",
      iconColor: "bg-gray-100 text-gray-600",
      path: "/dilution-calculator",
    },
  ];

  if (isLoading) {
    return (
      <div className="space-y-8">
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-neutral-700 mb-2">Laboratory Dashboard</h2>
          <p className="text-neutral-500">Manage your research workflow with integrated tools for data collection, analysis, and documentation.</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {[1, 2, 3, 4].map(i => (
            <Card key={i} className="animate-pulse">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div className="space-y-2">
                    <div className="h-4 bg-gray-200 rounded w-20"></div>
                    <div className="h-8 bg-gray-200 rounded w-12"></div>
                  </div>
                  <div className="w-12 h-12 bg-gray-200 rounded-lg"></div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-neutral-700 mb-2">Laboratory Dashboard</h2>
        <p className="text-neutral-500">Manage your research workflow with integrated tools for data collection, analysis, and documentation.</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-neutral-500">Active Experiments</p>
                <p className="text-2xl font-bold text-neutral-700">{stats?.activeExperiments || 0}</p>
              </div>
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                <FlaskConical className="w-6 h-6 text-blue-600" />
              </div>
            </div>
            <div className="mt-4 flex items-center text-sm">
              <TrendingUp className="w-4 h-4 text-green-600 mr-1" />
              <span className="text-green-600">+2 this week</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-neutral-500">Animals Tracked</p>
                <p className="text-2xl font-bold text-neutral-700">{stats?.animalsTracked || 0}</p>
              </div>
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                <PawPrint className="w-6 h-6 text-green-600" />
              </div>
            </div>
            <div className="mt-4 flex items-center text-sm">
              <span className="text-neutral-500">No change</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-neutral-500">Notebook Entries</p>
                <p className="text-2xl font-bold text-neutral-700">{stats?.notebookEntries || 0}</p>
              </div>
              <div className="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center">
                <BookOpen className="w-6 h-6 text-yellow-600" />
              </div>
            </div>
            <div className="mt-4 flex items-center text-sm">
              <TrendingUp className="w-4 h-4 text-green-600 mr-1" />
              <span className="text-green-600">+7 this week</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-neutral-500">Freezer Samples</p>
                <p className="text-2xl font-bold text-neutral-700">{stats?.freezerSamples || 0}</p>
              </div>
              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                <Snowflake className="w-6 h-6 text-purple-600" />
              </div>
            </div>
            <div className="mt-4 flex items-center text-sm">
              <TrendingUp className="w-4 h-4 text-green-600 mr-1" />
              <span className="text-green-600">+18 this week</span>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Tool Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {toolCards.map((tool) => (
          <Card 
            key={tool.path} 
            className="hover:shadow-md transition-shadow cursor-pointer"
            onClick={() => navigate(tool.path)}
          >
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${tool.iconColor}`}>
                  <tool.icon className="w-6 h-6" />
                </div>
                <Badge className={tool.badgeColor}>
                  {tool.badge}
                </Badge>
              </div>
              <h3 className="text-lg font-semibold text-neutral-700 mb-2">{tool.title}</h3>
              <p className="text-neutral-500 text-sm mb-4">{tool.description}</p>
              <div className="flex items-center text-sm text-blue-600 font-medium">
                <span>Open Tool</span>
                <ArrowRight className="w-4 h-4 ml-2" />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Recent Activity */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg font-semibold text-neutral-700">Recent Activity</CardTitle>
        </CardHeader>
        <CardContent className="p-6 pt-0">
          <div className="space-y-4">
            <div className="flex items-center space-x-4 py-3 border-b border-neutral-100 last:border-b-0">
              <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                <FlaskConical className="w-5 h-5 text-blue-600" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-neutral-700">New experiment logged: LPS+ROT 2-week endpoint</p>
                <p className="text-xs text-neutral-500">2 hours ago</p>
              </div>
              <Badge className="bg-green-100 text-green-700">
                Experiment
              </Badge>
            </div>
            
            <div className="flex items-center space-x-4 py-3 border-b border-neutral-100 last:border-b-0">
              <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                <BarChart3 className="w-5 h-5 text-green-600" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-neutral-700">Statistical analysis completed for gut permeability data</p>
                <p className="text-xs text-neutral-500">4 hours ago</p>
              </div>
              <Badge className="bg-blue-100 text-blue-700">
                Analysis
              </Badge>
            </div>

            <div className="flex items-center space-x-4 py-3">
              <div className="w-10 h-10 bg-yellow-100 rounded-full flex items-center justify-center flex-shrink-0">
                <PawPrint className="w-5 h-5 text-yellow-600" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-neutral-700">Animal weights updated for cohort C57BL/6J</p>
                <p className="text-xs text-neutral-500">Yesterday</p>
              </div>
              <Badge className="bg-yellow-100 text-yellow-700">
                Research
              </Badge>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
