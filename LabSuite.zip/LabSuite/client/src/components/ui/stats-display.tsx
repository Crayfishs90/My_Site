import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

interface StatsDisplayProps {
  results: any;
}

export default function StatsDisplay({ results }: StatsDisplayProps) {
  if (!results) return null;

  return (
    <div className="space-y-6">
      {/* Descriptive Statistics */}
      {results.descriptive && (
        <div>
          <h4 className="font-semibold text-neutral-700 mb-3">Descriptive Statistics</h4>
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-neutral-200">
              <thead className="bg-neutral-50">
                <tr>
                  <th className="px-4 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Group</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">N</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Mean</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">SD</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">SEM</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Min-Max</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-neutral-200">
                {Object.entries(results.descriptive).map(([group, stats]: [string, any]) => (
                  <tr key={group}>
                    <td className="px-4 py-3 text-sm font-medium text-neutral-700">{group}</td>
                    <td className="px-4 py-3 text-sm text-neutral-600">{stats.n}</td>
                    <td className="px-4 py-3 text-sm text-neutral-600">{stats.mean}</td>
                    <td className="px-4 py-3 text-sm text-neutral-600">{stats.sd}</td>
                    <td className="px-4 py-3 text-sm text-neutral-600">{stats.sem}</td>
                    <td className="px-4 py-3 text-sm text-neutral-600">{stats.min} - {stats.max}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Test Results */}
      <div>
        <h4 className="font-semibold text-neutral-700 mb-3">{results.test} Results</h4>
        <Card>
          <CardContent className="p-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-center">
              {results.f && (
                <div>
                  <p className="text-sm text-neutral-500">F-statistic</p>
                  <p className="text-lg font-semibold text-neutral-700">{results.f}</p>
                </div>
              )}
              {results.t && (
                <div>
                  <p className="text-sm text-neutral-500">t-statistic</p>
                  <p className="text-lg font-semibold text-neutral-700">{results.t}</p>
                </div>
              )}
              <div>
                <p className="text-sm text-neutral-500">p-value</p>
                <p className="text-lg font-semibold text-red-600">
                  {results.pValue < 0.001 ? '< 0.001' : results.pValue.toFixed(3)}
                </p>
              </div>
              <div>
                <p className="text-sm text-neutral-500">Significance</p>
                <Badge className={results.significant ? 'bg-red-100 text-red-800' : 'bg-gray-100 text-gray-800'}>
                  {results.significant ? 'Significant' : 'Not Significant'}
                </Badge>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Mean Difference for t-test */}
      {results.meanDiff !== undefined && (
        <div>
          <h4 className="font-semibold text-neutral-700 mb-3">Mean Difference</h4>
          <Card>
            <CardContent className="p-4">
              <div className="text-center">
                <p className="text-sm text-neutral-500">Difference between groups</p>
                <p className="text-lg font-semibold text-neutral-700">{results.meanDiff}</p>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Groups tested */}
      {results.groups && (
        <div>
          <h4 className="font-semibold text-neutral-700 mb-3">Groups Analyzed</h4>
          <div className="flex flex-wrap gap-2">
            {results.groups.map((group: string) => (
              <Badge key={group} variant="outline">{group}</Badge>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
